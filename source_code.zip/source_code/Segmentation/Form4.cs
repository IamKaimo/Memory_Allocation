﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segmentation
{
    public partial class Form4 : Form
    {
        private Form _ftr;
        public bool isComb;
        public Form4()
        {
            InitializeComponent();
        }
        public Form4(Form1 frm,bool isC)
        {
            InitializeComponent();
            isComb = isC;
            _ftr = frm;
        }
        private void close()
        {
            _ftr.Enabled = true;
            this.Close();
        }
        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            _ftr.Enabled = true;
        }

        private void dealloc_Click(object sender, EventArgs e)
        {
            if(comboBox2.SelectedIndex == -1) 
            {
                MessageBox.Show("No Selected Process!");
            }
            else
            {
                int x = Convert.ToInt32(comboBox2.SelectedItem.ToString());
                if (comboBox1.SelectedIndex == 0) //process
                {
                    for (int i = 0; i < Segmentation_Algorithm.memory.Count; i++)
                    {
                        if (Segmentation_Algorithm.memory[i].get_type() == "process")
                        {
                            if (Segmentation_Algorithm.memory[i].get_id() == x)
                            {
                                Node.DeallocateProcess(i, Segmentation_Algorithm.memory);
                                i--;
                            }
                        }
                    }
                }
                else // old process
                {
                    int index = -1;
                    for(int i=0;i< Segmentation_Algorithm.memory.Count; i++)
                    {
                        if(Segmentation_Algorithm.memory[i].get_type() == "old")
                        {
                            index++;
                            if(index == x)
                            {
                                Node.DeallocateProcess(i, Segmentation_Algorithm.memory);
                                break;
                            }
                        }
                    }
                }
                if (isComb) Node.Check_Your_Holes(Segmentation_Algorithm.memory);
                close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0)
            {
                List<int> ID = new List<int>();
                for (int i = 0; i < Segmentation_Algorithm.memory.Count; i++)
                {
                    if (Segmentation_Algorithm.memory[i].get_type() == "process")
                    {
                        int id = Segmentation_Algorithm.memory[i].get_id();
                        if(ID.Count == 0)
                        {
                            ID.Add(id);
                        }
                        else
                        {
                            for(int j = 0; j < ID.Count; j++)
                            {
                                if (ID[j] == id) break;
                                else if (ID[j] > id) { ID.Insert(j, id); break; }
                                if(j == ID.Count - 1) ID.Insert(j+1, id);
                            }
                        }
                    }
                }
                comboBox2.Items.Clear();
                if (ID.Count > 0)
                {
                    for (int i = 0; i < ID.Count; i++) comboBox2.Items.Add(ID[i]);
                }
            }
            else
            {
                int max = -1;
                for(int i = 0; i < Segmentation_Algorithm.memory.Count; i++)    
                    if (Segmentation_Algorithm.memory[i].get_type() == "old") max++;
                comboBox2.Items.Clear();
                if (max != -1)
                {
                    for (int i = 0; i < max + 1; i++)comboBox2.Items.Add(i);
                }
            }
        }
    }


}
