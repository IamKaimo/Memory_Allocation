﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;

namespace Segmentation
{
    class Segmentation_Algorithm
    {
        private static int total_MemorySize = -1;
        public static void set_MemorySize(String mTextBox)
        {
            total_MemorySize = Convert.ToInt32(mTextBox);
        }
        public static int get_MemorySize()
        {
            return total_MemorySize;
        }
        public static Hole[] holeArray;
        public static Hole[] Latest_Fine_holeArray;
        public static List<Node> memory = new List<Node>();
        public static int holeLimit = 0;
        public static bool setHoleArray(DataGridView dataGridView)
        {
            bool pass = true;
            holeArray = new Hole[dataGridView.Rows.Count];
            int b, c;
            string header;
            for (int i = 0; i < dataGridView.Rows.Count; i++)
            {
                header = "holes_StartingAddress";
                b = (dataGridView.Rows
                .Cast<DataGridViewRow>()
                .Where(row => !row.IsNewRow)
                .Select(row => Convert.ToInt32(row.Cells[header].Value)).ToArray())[i];

                header = "holes_Size";
                c = (dataGridView.Rows
                .Cast<DataGridViewRow>()
                .Where(row => !row.IsNewRow)
                .Select(row => Convert.ToInt32(row.Cells[header].Value)).ToArray())[i];

                holeArray[i] = new Hole(b, c);
            }

            for(int i = 0; i < holeArray.Length; i++)
            {
                int start = holeArray[i].get_HoleStartingAddress();
                int end = start + holeArray[i].get_HoleSize() -1;
                for (int j = i + 1; j < holeArray.Length; j++) if ((start >= holeArray[j].get_HoleStartingAddress() - 1 && start <= holeArray[j].get_HoleStartingAddress() + holeArray[j].get_HoleSize()) || (end <= holeArray[j].get_HoleStartingAddress() + holeArray[i].get_HoleSize() && end >= holeArray[j].get_HoleStartingAddress() - 1)){ pass = false; return pass; }
            }
            return pass;
        }
        public static bool check_hole_memorysize()
        {
            if (holeArray != null && holeArray.Length != 0)
            {
                for (int i = 0; i < holeArray.Length; i++) if (holeArray[i].get_HoleStartingAddress() + holeArray[i].get_HoleSize() > total_MemorySize) return false;
                Latest_Fine_holeArray = new Hole[holeArray.Length];
                for(int i=0;i< holeArray.Length;i++) Latest_Fine_holeArray[i] = holeArray[i];
                return true;
            }
            Latest_Fine_holeArray = null;
            holeLimit = 0;
            return true;
        }
        public static void holeSortingbyAddress(Hole[] currentHoleArray)
        {
            if (currentHoleArray.Length == 2 && currentHoleArray[0].get_HoleSize() == 0 && currentHoleArray[1].get_HoleSize() == 0 && currentHoleArray[0].get_HoleStartingAddress() == 0 && currentHoleArray[1].get_HoleStartingAddress() == total_MemorySize)
            { }
            else
            {

                int currentHoleArraySize = currentHoleArray.Length;
                int x = currentHoleArraySize - 1;
                if (currentHoleArraySize > 0)
                {

                    for (int j = 0; j <= x; j++)
                    {
                        int minimum = currentHoleArray[j].get_HoleStartingAddress();
                        Hole temp;
                        if (minimum == -1)
                        {
                            if (j >= x)
                            {
                                break;
                            }


                            temp = currentHoleArray[j];

                            currentHoleArray[j] = currentHoleArray[x];
                            currentHoleArray[x] = temp;
                            x--;
                            j--;
                            continue;
                        }
                        int minimum_index = j;

                        for (int i = j + 1; i < currentHoleArraySize; i++)
                        {
                            if (currentHoleArray[i].get_HoleStartingAddress() < minimum && currentHoleArray[i].get_HoleStartingAddress() != -1)
                            {
                                minimum_index = i;
                                minimum = currentHoleArray[i].get_HoleStartingAddress();
                            }
                        }
                        if (minimum_index != j)
                        {
                            temp = currentHoleArray[j];
                            currentHoleArray[j] = currentHoleArray[minimum_index];
                            currentHoleArray[minimum_index] = temp;
                        }

                    }
                }
            }
        }
    }
}
               



