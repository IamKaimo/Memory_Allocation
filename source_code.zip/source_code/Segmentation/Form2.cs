﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segmentation
{
    public partial class Form2 : Form
    {
        private Form1 _frm;
        public Form2()
        {
            InitializeComponent();
        }
        public void take_data(Form1 frm)
        {
            _frm = frm;
        }
        public void clear()
        {
            while (holes_Data.RowCount != 0) holes_Data.Rows.RemoveAt(0);
            Segmentation_Algorithm.Latest_Fine_holeArray = null;
            Segmentation_Algorithm.holeLimit = 0;
            Node.AddHoles(null, Segmentation_Algorithm.memory);
        }
        private void ok_form2_Click(object sender, EventArgs e)
        {
            for (int i = 0,x; i < holes_Data.RowCount * holes_Data.ColumnCount; i++)
            {
                if(holes_Data.Rows[i / holes_Data.ColumnCount].Cells[i % holes_Data.ColumnCount].Value == null) { MessageBox.Show("Please Fill All Holes With Correct Data!\n[There is/are Empty Data Cell/s]"); return; }
                else if (int.TryParse(holes_Data.Rows[i / holes_Data.ColumnCount].Cells[i % holes_Data.ColumnCount].Value.ToString(), out x))
                {
                    if (x < 0 || ((x<1) && (i % holes_Data.ColumnCount == 1))) { MessageBox.Show("Please Fill All Holes With Correct Data!\n[Start Address >=0 and Size > 0]"); return; }
                }
                else { MessageBox.Show("Please Fill All Holes With Correct Data!\n[There is/are Non-Integer Number/s]"); return; }
            }

            if(!Segmentation_Algorithm.setHoleArray(holes_Data)) { MessageBox.Show("Intersection or cohesion between holes exist,\nPlease merge them into one hole!"); return; };
            if (!Segmentation_Algorithm.check_hole_memorysize()) { MessageBox.Show("Insufficient memory for holes!, holes exceeds the memory"); return; }
         
            if (Segmentation_Algorithm.Latest_Fine_holeArray != null)
            {
                Segmentation_Algorithm.holeSortingbyAddress(Segmentation_Algorithm.Latest_Fine_holeArray);
                Segmentation_Algorithm.holeLimit = Segmentation_Algorithm.Latest_Fine_holeArray[Segmentation_Algorithm.Latest_Fine_holeArray.Length - 1].get_HoleStartingAddress() + Segmentation_Algorithm.Latest_Fine_holeArray[Segmentation_Algorithm.Latest_Fine_holeArray.Length - 1].get_HoleSize() - 1;

            }
            _frm.Enabled = true;
            this.Hide();
        }
        private void newHoleEntryButton_Click(object sender, EventArgs e)
        {
            holes_Data.Rows.Add();
        }
        private void deleteHoleEntryButton_Click(object sender, EventArgs e)
        {
            if (this.holes_Data.SelectedCells.Count > 0)    this.holes_Data.Rows.RemoveAt(this.holes_Data.SelectedCells[0].RowIndex);
            if(this.holes_Data.Rows.Count ==0) deleteHoleEntryButton.Enabled = false;
        }
        private void holes_Data_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            deleteHoleEntryButton.Enabled = true;
        }
        private void Close_Click(object sender, EventArgs e)
        {
            _frm.Enabled = true;
            this.Hide();
            while (holes_Data.RowCount!=0) holes_Data.Rows.RemoveAt(0);
            if (Segmentation_Algorithm.Latest_Fine_holeArray != null)
            {
                for (int i = 0; i < Segmentation_Algorithm.Latest_Fine_holeArray.Length; i++)
                {
                    holes_Data.Rows.Add();
                    holes_Data.Rows[i].Cells[0].Value = Segmentation_Algorithm.Latest_Fine_holeArray[i].get_HoleStartingAddress();
                    holes_Data.Rows[i].Cells[1].Value = Segmentation_Algorithm.Latest_Fine_holeArray[i].get_HoleSize();
                }
            }
        }
    }
}
