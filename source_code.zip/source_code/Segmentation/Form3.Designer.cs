﻿namespace Segmentation
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.segmentsDataGridView = new System.Windows.Forms.DataGridView();
            this.segmentName_Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.segSizesColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.segments_Label = new System.Windows.Forms.Label();
            this.Lock = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Unlock = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.best_fit = new System.Windows.Forms.RadioButton();
            this.first_fit = new System.Windows.Forms.RadioButton();
            this.worst_fit = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.segmentsDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // segmentsDataGridView
            // 
            this.segmentsDataGridView.AllowUserToAddRows = false;
            this.segmentsDataGridView.AllowUserToDeleteRows = false;
            this.segmentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.segmentsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.segmentName_Column,
            this.segSizesColumn});
            this.segmentsDataGridView.Enabled = false;
            this.segmentsDataGridView.Location = new System.Drawing.Point(44, 101);
            this.segmentsDataGridView.Name = "segmentsDataGridView";
            this.segmentsDataGridView.RowHeadersWidth = 51;
            this.segmentsDataGridView.RowTemplate.Height = 24;
            this.segmentsDataGridView.Size = new System.Drawing.Size(537, 181);
            this.segmentsDataGridView.TabIndex = 3;
            // 
            // segmentName_Column
            // 
            this.segmentName_Column.HeaderText = "Segment Name";
            this.segmentName_Column.MinimumWidth = 150;
            this.segmentName_Column.Name = "segmentName_Column";
            this.segmentName_Column.Width = 150;
            // 
            // segSizesColumn
            // 
            this.segSizesColumn.HeaderText = "Size of Segment";
            this.segSizesColumn.MinimumWidth = 180;
            this.segSizesColumn.Name = "segSizesColumn";
            this.segSizesColumn.Width = 180;
            // 
            // segments_Label
            // 
            this.segments_Label.AutoSize = true;
            this.segments_Label.Enabled = false;
            this.segments_Label.Location = new System.Drawing.Point(41, 81);
            this.segments_Label.Name = "segments_Label";
            this.segments_Label.Size = new System.Drawing.Size(178, 17);
            this.segments_Label.TabIndex = 4;
            this.segments_Label.Text = "Segments and Their Sizes:";
            // 
            // Lock
            // 
            this.Lock.Location = new System.Drawing.Point(457, 30);
            this.Lock.Name = "Lock";
            this.Lock.Size = new System.Drawing.Size(88, 23);
            this.Lock.TabIndex = 11;
            this.Lock.Text = "Lock";
            this.Lock.UseVisualStyleBackColor = true;
            this.Lock.Click += new System.EventHandler(this.Lock_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Enter Segments Number:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(226, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(137, 22);
            this.textBox1.TabIndex = 13;
            // 
            // Unlock
            // 
            this.Unlock.Location = new System.Drawing.Point(457, 30);
            this.Unlock.Name = "Unlock";
            this.Unlock.Size = new System.Drawing.Size(87, 23);
            this.Unlock.TabIndex = 14;
            this.Unlock.Text = "Unlock";
            this.Unlock.UseVisualStyleBackColor = true;
            this.Unlock.Visible = false;
            this.Unlock.Click += new System.EventHandler(this.Unlock_Click);
            // 
            // add
            // 
            this.add.Enabled = false;
            this.add.Location = new System.Drawing.Point(458, 429);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(123, 38);
            this.add.TabIndex = 15;
            this.add.Text = "Add Process";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(44, 429);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(128, 38);
            this.cancel.TabIndex = 16;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.best_fit);
            this.groupBox1.Controls.Add(this.first_fit);
            this.groupBox1.Controls.Add(this.worst_fit);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(404, 304);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(177, 104);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose Algorithm :";
            // 
            // best_fit
            // 
            this.best_fit.AutoSize = true;
            this.best_fit.Checked = true;
            this.best_fit.Location = new System.Drawing.Point(18, 21);
            this.best_fit.Name = "best_fit";
            this.best_fit.Size = new System.Drawing.Size(76, 21);
            this.best_fit.TabIndex = 7;
            this.best_fit.TabStop = true;
            this.best_fit.Text = "Best Fit";
            this.best_fit.UseVisualStyleBackColor = true;
            // 
            // first_fit
            // 
            this.first_fit.AutoSize = true;
            this.first_fit.Location = new System.Drawing.Point(18, 48);
            this.first_fit.Name = "first_fit";
            this.first_fit.Size = new System.Drawing.Size(75, 21);
            this.first_fit.TabIndex = 8;
            this.first_fit.Text = "First Fit";
            this.first_fit.UseVisualStyleBackColor = true;
            // 
            // worst_fit
            // 
            this.worst_fit.AutoSize = true;
            this.worst_fit.Location = new System.Drawing.Point(18, 75);
            this.worst_fit.Name = "worst_fit";
            this.worst_fit.Size = new System.Drawing.Size(85, 21);
            this.worst_fit.TabIndex = 9;
            this.worst_fit.Text = "Worst Fit";
            this.worst_fit.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 494);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.add);
            this.Controls.Add(this.Unlock);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Lock);
            this.Controls.Add(this.segments_Label);
            this.Controls.Add(this.segmentsDataGridView);
            this.Name = "Form3";
            this.Text = "Process and Segments";
            ((System.ComponentModel.ISupportInitialize)(this.segmentsDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView segmentsDataGridView;
        private System.Windows.Forms.Label segments_Label;
        private System.Windows.Forms.DataGridViewTextBoxColumn segmentName_Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn segSizesColumn;
        private System.Windows.Forms.Button Lock;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Unlock;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton best_fit;
        private System.Windows.Forms.RadioButton first_fit;
        private System.Windows.Forms.RadioButton worst_fit;
    }
}