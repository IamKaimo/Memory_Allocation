﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Segmentation
{
    public class Hole
    {
        private int mStartingAddress = -1;
        private int mSize = 0;

        public Hole(int startingAddress, int size)
        {
            mStartingAddress = startingAddress;
            mSize = size;

        }

        public int get_HoleStartingAddress()
        {
            return mStartingAddress;
        }

        public void set_HoleStartingAddress(int startingAddress)
        {
            mStartingAddress = startingAddress;
        }

        public int get_HoleSize()
        {
            return mSize;
        }

        public void set_HoleSize(int size)
        {
            mSize = size;
        }
    }
}
