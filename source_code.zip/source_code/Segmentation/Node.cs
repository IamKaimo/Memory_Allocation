﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Segmentation
{
    public class Node
    {
        int start = 0, end = 0, size = 0, process_id = 0;
        string type = "none",segment_name="none";


        public string[] segment_names = null;
        public int[] segment_size = null;
        static int p_id = 0;

        public Node(int s,int e,string t)   // hole
        {
            type = t;
            start = s;
            end = e;
            size = e - s + 1;
        }
        public Node(int s, int e, string t,int pro_id,string seg_name) // process
        {
            type = t;
            start = s;
            end = e;
            size = e - s + 1;
            process_id = pro_id;
            segment_name = seg_name;
        }
        public Node(string t,string[] s_names,int[] s_size) //data process
        {
            type = t;
            segment_names = s_names;
            segment_size = s_size;
        }

        public int get_start() { return start; }
        public int get_end() { return end; }
        public int get_size() { return size; }
        public int get_id() { return process_id; }
        public string get_type() { return type; }
        public string get_name() { return segment_name; }

        public void set_start(int s)
        {
            start = s;
            size = end - start + 1;
        }
        public void set_end(int e)
        {
            end = e;
            size = end - start + 1;
        }
        public void set_type(string x)
        {
            type = x;
        }
        public static void AddHoles(Hole[] holes, List<Node> memory)
        {
            while (memory.Count > 0) memory.RemoveAt(0);
            if (holes == null)
            {
                memory.Add(new Node(0, Segmentation_Algorithm.get_MemorySize() - 1, "old"));
                return;
            }
            for (int i = 0; i < holes.Length; i++)
            {
                memory.Add(new Node(holes[i].get_HoleStartingAddress(), holes[i].get_HoleSize() + holes[i].get_HoleStartingAddress() - 1, "hole"));
            }

            if(memory[0].get_start() > 0) { memory.Insert(0, new Node(0, memory[0].get_start() - 1, "old")); }
            for (int i = 0; i < memory.Count - 1; i++)
            {
                if (memory[i].get_type() == "old") continue;
                int a = memory[i].get_end();
                int b = memory[i + 1].get_start();
                memory.Insert(i + 1, new Node(a + 1, b - 1, "old"));
            }
            if (memory[memory.Count - 1].get_end() < Segmentation_Algorithm.get_MemorySize() - 1) { memory.Insert(memory.Count,new Node(memory[memory.Count - 1].get_end() + 1, Segmentation_Algorithm.get_MemorySize() - 1, "old")); }

            foreach (Node num in memory)
            {
                int x = num.get_start();
                string xx = num.get_type();
            }
        }

        public static void Check_Your_Holes(List<Node> memory)
        {
            int shift = 0;
            for(int i = 0; i < memory.Count; i++)
            {
                int old_size = memory[i].get_size();
                memory[i].set_start(memory[i].get_start() - shift);
                memory[i].set_end(memory[i].get_start() + old_size - 1);
                if (memory[i].get_type() == "hole")
                {
                    shift += memory[i].get_size();
                    memory.RemoveAt(i);
                    i--;
                }
            }
            if(shift > 0)
            {
                if(memory.Count == 0) memory.Add(new Node(0, shift - 1, "hole"));
                else memory.Add(new Node(memory[memory.Count - 1].get_end() + 1, memory[memory.Count - 1].get_end() + shift, "hole"));
            }
        }
        public static void AllocateProcess(Node Process,List<Node> memory, string Algo)
        {
            if(Algo == "ff")
            {
                for (int index = 0; index < Process.segment_size.Length; index++) {
                    for (int i = 0; i < memory.Count; i++)
                    {
                        if ((memory[i].get_type()=="hole") && memory[i].get_size() >= Process.segment_size[index])
                        {
                            if(memory[i].get_size() > Process.segment_size[index])
                            {
                                int start = memory[i].get_start();
                                memory[i].set_start(start + Process.segment_size[index]);
                                memory.Insert(i, new Node(start, start + Process.segment_size[index] - 1, "process", Node.p_id, Process.segment_names[index]));
                                break;
                            }
                            else
                            {
                                int start=memory[i].get_start();
                                memory.RemoveAt(i);
                                memory.Insert(i, new Node(start, start + Process.segment_size[index] - 1, "process", Node.p_id, Process.segment_names[index]));
                                break;
                            }
                        }
                    }
                }
                Node.p_id++;
            }
            else if(Algo == "bf")
            {
                for (int index = 0; index < Process.segment_size.Length; index++)
                {
                    int target = -1; 
                    for(int i = 0; i < memory.Count; i++)
                    {
                        if (memory[i].get_type() != "hole") continue;
                        if (memory[i].get_size() >= Process.segment_size[index] && (target == -1 || memory[i].get_size() < memory[target].get_size()))
                        {
                            target = i;
                        }
                    }
                    if (memory[target].get_size() > Process.segment_size[index])
                    {
                        int start = memory[target].get_start();
                        memory[target].set_start(start + Process.segment_size[index]);
                        memory.Insert(target, new Node(start, start + Process.segment_size[index] - 1, "process", Node.p_id, Process.segment_names[index]));
                    }
                    else
                    {
                        int start = memory[target].get_start();
                        memory.RemoveAt(target);
                        memory.Insert(target, new Node(start, start + Process.segment_size[index] - 1, "process", Node.p_id, Process.segment_names[index]));
                    }   
                }
                Node.p_id++;
            }
            else
            {
                for (int index = 0; index < Process.segment_size.Length; index++)
                {
                    int target = -1;
                    for (int i = 0; i < memory.Count; i++)
                    {
                        if (memory[i].get_type() != "hole") continue;
                        if (memory[i].get_size() >= Process.segment_size[index] && (target == -1 || memory[i].get_size() > memory[target].get_size()))
                        {
                            target = i;
                        }
                    }
                    if (memory[target].get_size() > Process.segment_size[index])
                    {
                        int start = memory[target].get_start();
                        memory[target].set_start(start + Process.segment_size[index]);
                        memory.Insert(target, new Node(start, start + Process.segment_size[index] - 1, "process", Node.p_id, Process.segment_names[index]));
                    }
                    else
                    {
                        int start = memory[target].get_start();
                        memory.RemoveAt(target);
                        memory.Insert(target, new Node(start, start + Process.segment_size[index] - 1, "process", Node.p_id, Process.segment_names[index]));
                    }
                }
                Node.p_id++;
            }
        }
        public static void DeallocateProcess(int index,List<Node> memory) 
        {
            if(memory.Count == 1)
            {
                memory[index].set_type("hole");
            }
            else if(index == 0)
            {
                if (memory[index + 1].get_type() == "hole")
                {
                    int start = memory[index].get_start();
                    memory[index + 1].set_start(start);
                    memory.RemoveAt(index);
                }
                else
                {
                    memory[index].set_type("hole");
                }
            }
            else if(index == memory.Count - 1)
            {
                if (memory[index - 1].get_type() == "hole")
                {
                    int end = memory[index].get_end();
                    memory[index - 1].set_end(end);
                    memory.RemoveAt(index);
                }
                else
                {
                    memory[index].set_type("hole");
                }
            }
            else
            {
                if(memory[index - 1].get_type() == "hole" && memory[index + 1].get_type() == "hole")
                {
                    int end = memory[index + 1].get_end();
                    memory.RemoveAt(index);
                    memory.RemoveAt(index);
                    memory[index - 1].set_end(end);
                }
                else if (memory[index - 1].get_type() == "hole")
                {
                    int end = memory[index].get_end();
                    memory[index - 1].set_end(end);
                    memory.RemoveAt(index);
                }
                else if (memory[index + 1].get_type() == "hole")
                {
                    int start = memory[index].get_start();
                    memory[index + 1].set_start(start);
                    memory.RemoveAt(index);
                }
                else
                {
                    memory[index].set_type("hole");
                }
            }
        
        }
    }
}
