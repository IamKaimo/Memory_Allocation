﻿namespace Segmentation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.totalMemorySize_TextBox = new System.Windows.Forms.TextBox();
            this.fillHolesEntry = new System.Windows.Forms.Button();
            this.fillProcessEntry = new System.Windows.Forms.Button();
            this.save_MemoryButton = new System.Windows.Forms.Button();
            this.compactionRB = new System.Windows.Forms.RadioButton();
            this.withoutCompactionRB = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.deallocate = new System.Windows.Forms.Button();
            this.save_holes = new System.Windows.Forms.Button();
            this.edit_holes = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total Memory Size:";
            // 
            // totalMemorySize_TextBox
            // 
            this.totalMemorySize_TextBox.Location = new System.Drawing.Point(148, 60);
            this.totalMemorySize_TextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.totalMemorySize_TextBox.Name = "totalMemorySize_TextBox";
            this.totalMemorySize_TextBox.Size = new System.Drawing.Size(165, 20);
            this.totalMemorySize_TextBox.TabIndex = 2;
            // 
            // fillHolesEntry
            // 
            this.fillHolesEntry.Enabled = false;
            this.fillHolesEntry.Location = new System.Drawing.Point(19, 150);
            this.fillHolesEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.fillHolesEntry.Name = "fillHolesEntry";
            this.fillHolesEntry.Size = new System.Drawing.Size(92, 65);
            this.fillHolesEntry.TabIndex = 3;
            this.fillHolesEntry.Text = "Fill Holes";
            this.fillHolesEntry.UseVisualStyleBackColor = true;
            this.fillHolesEntry.Click += new System.EventHandler(this.fillHoleEntry_Click);
            // 
            // fillProcessEntry
            // 
            this.fillProcessEntry.Enabled = false;
            this.fillProcessEntry.Location = new System.Drawing.Point(19, 422);
            this.fillProcessEntry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.fillProcessEntry.Name = "fillProcessEntry";
            this.fillProcessEntry.Size = new System.Drawing.Size(188, 171);
            this.fillProcessEntry.TabIndex = 5;
            this.fillProcessEntry.Text = "Allocate Process";
            this.fillProcessEntry.UseVisualStyleBackColor = true;
            this.fillProcessEntry.Click += new System.EventHandler(this.fillProcessEntry_Click);
            // 
            // save_MemoryButton
            // 
            this.save_MemoryButton.Location = new System.Drawing.Point(369, 40);
            this.save_MemoryButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.save_MemoryButton.Name = "save_MemoryButton";
            this.save_MemoryButton.Size = new System.Drawing.Size(86, 54);
            this.save_MemoryButton.TabIndex = 10;
            this.save_MemoryButton.Text = "Save Memory";
            this.save_MemoryButton.UseVisualStyleBackColor = true;
            this.save_MemoryButton.Click += new System.EventHandler(this.save_MemoryButton_Click);
            // 
            // compactionRB
            // 
            this.compactionRB.AutoSize = true;
            this.compactionRB.Location = new System.Drawing.Point(4, 39);
            this.compactionRB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.compactionRB.Name = "compactionRB";
            this.compactionRB.Size = new System.Drawing.Size(106, 17);
            this.compactionRB.TabIndex = 11;
            this.compactionRB.Text = "With Compaction";
            this.compactionRB.UseVisualStyleBackColor = true;
            // 
            // withoutCompactionRB
            // 
            this.withoutCompactionRB.AutoSize = true;
            this.withoutCompactionRB.Checked = true;
            this.withoutCompactionRB.Location = new System.Drawing.Point(4, 17);
            this.withoutCompactionRB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.withoutCompactionRB.Name = "withoutCompactionRB";
            this.withoutCompactionRB.Size = new System.Drawing.Size(121, 17);
            this.withoutCompactionRB.TabIndex = 12;
            this.withoutCompactionRB.TabStop = true;
            this.withoutCompactionRB.Text = "Without Compaction";
            this.withoutCompactionRB.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.compactionRB);
            this.groupBox2.Controls.Add(this.withoutCompactionRB);
            this.groupBox2.Enabled = false;
            this.groupBox2.Location = new System.Drawing.Point(149, 150);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(164, 65);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Choose Option :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(369, 40);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 54);
            this.button1.TabIndex = 15;
            this.button1.Text = "Edit Memory";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // deallocate
            // 
            this.deallocate.Enabled = false;
            this.deallocate.Location = new System.Drawing.Point(267, 422);
            this.deallocate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.deallocate.Name = "deallocate";
            this.deallocate.Size = new System.Drawing.Size(188, 171);
            this.deallocate.TabIndex = 16;
            this.deallocate.Text = "Deallocate Process";
            this.deallocate.UseVisualStyleBackColor = true;
            this.deallocate.Click += new System.EventHandler(this.deallocate_Click);
            // 
            // save_holes
            // 
            this.save_holes.Enabled = false;
            this.save_holes.Location = new System.Drawing.Point(370, 157);
            this.save_holes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.save_holes.Name = "save_holes";
            this.save_holes.Size = new System.Drawing.Size(86, 51);
            this.save_holes.TabIndex = 17;
            this.save_holes.Text = "Save Holes";
            this.save_holes.UseVisualStyleBackColor = true;
            this.save_holes.Click += new System.EventHandler(this.save_holes_Click);
            // 
            // edit_holes
            // 
            this.edit_holes.Location = new System.Drawing.Point(370, 156);
            this.edit_holes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.edit_holes.Name = "edit_holes";
            this.edit_holes.Size = new System.Drawing.Size(86, 52);
            this.edit_holes.TabIndex = 18;
            this.edit_holes.Text = "Edit Holes";
            this.edit_holes.UseVisualStyleBackColor = true;
            this.edit_holes.Visible = false;
            this.edit_holes.Click += new System.EventHandler(this.edit_holes_Click);
            // 
            // panel1
            // 
            this.panel1.Enabled = false;
            this.panel1.Location = new System.Drawing.Point(466, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.MaximumSize = new System.Drawing.Size(150, 765);
            this.panel1.MinimumSize = new System.Drawing.Size(150, 765);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 765);
            this.panel1.TabIndex = 19;
            this.panel1.Visible = false;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 687);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.edit_holes);
            this.Controls.Add(this.save_holes);
            this.Controls.Add(this.deallocate);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.save_MemoryButton);
            this.Controls.Add(this.fillProcessEntry);
            this.Controls.Add(this.fillHolesEntry);
            this.Controls.Add(this.totalMemorySize_TextBox);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(642, 726);
            this.MinimumSize = new System.Drawing.Size(642, 726);
            this.Name = "Form1";
            this.Text = "Memory Allocation";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox totalMemorySize_TextBox;
        private System.Windows.Forms.Button fillHolesEntry;
        private System.Windows.Forms.Button fillProcessEntry;
        private System.Windows.Forms.Button save_MemoryButton;
        private System.Windows.Forms.RadioButton compactionRB;
        private System.Windows.Forms.RadioButton withoutCompactionRB;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button deallocate;
        private System.Windows.Forms.Button save_holes;
        private System.Windows.Forms.Button edit_holes;
        private System.Windows.Forms.Panel panel1;
    }
}

