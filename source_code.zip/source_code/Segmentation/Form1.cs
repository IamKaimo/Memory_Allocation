﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segmentation
{
    public partial class Form1 : Form
    {
        private static int _panelHeight = 660;
        private static int _panelWidth = 200;
        private static int _rectangleWidth = 80;

        public Form1()
        {
            InitializeComponent();
        }

        private void save_MemoryButton_Click(object sender, EventArgs e)
        {
            int x;
            if (int.TryParse(totalMemorySize_TextBox.Text, out x))
            {
                if (x > 0)
                {
                    Segmentation_Algorithm.set_MemorySize(totalMemorySize_TextBox.Text);
                    label1.Enabled = false;
                    totalMemorySize_TextBox.Enabled = false;
                    save_MemoryButton.Visible = false;
                    button1.Visible = true;
                    fillHolesEntry.Enabled = true;
                    groupBox2.Enabled = true;
                    save_holes.Enabled = true;
                    edit_holes.Visible = false;
                    fillProcessEntry.Enabled = false;
                    deallocate.Enabled = false;
                    panel1.Enabled = true;
                    panel1.Visible = true;

                    if (x < Segmentation_Algorithm.holeLimit + 1)
                    {
                        MessageBox.Show("Memory is smaller than inserted holes,\nholes fill will be reset!");
                        Forms.form2.clear();
                    }
                    Node.AddHoles(null, Segmentation_Algorithm.memory);
                    panel1.Refresh();
                    return;
                }
            }
            MessageBox.Show("Please Enter Positive Integer Number!");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            fillHolesEntry.Enabled = false;
            fillProcessEntry.Enabled = false;
            deallocate.Enabled = false;
            groupBox2.Enabled = false;
            totalMemorySize_TextBox.Enabled = true;
            save_MemoryButton.Visible = true;
            edit_holes.Visible = false;
            button1.Visible = false;
            label1.Enabled = true;
            save_holes.Enabled = false;
            save_holes.Visible = true;
            panel1.Enabled = false;
            panel1.Visible = false;

        }
        private void fillHoleEntry_Click(object sender, EventArgs e)
        {
            Forms.form2.take_data(Forms.form1);
            Forms.form2.Show();
            this.Enabled = false;
        }
        /**/
        private void fillProcessEntry_Click(object sender, EventArgs e)
        {
            new Form3(Forms.form1).Show();
            this.Enabled = false;
        }

        private void edit_holes_Click(object sender, EventArgs e)
        {
            fillHolesEntry.Enabled = true;
            groupBox2.Enabled = true;
            save_holes.Visible = true;
            save_holes.Enabled = true;
            edit_holes.Visible = false;
            fillProcessEntry.Enabled = false;
            deallocate.Enabled = false;
            Node.AddHoles(null, Segmentation_Algorithm.memory);
            panel1.Refresh();
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            List<System.Drawing.Size> _rectangleDataSize = new List<System.Drawing.Size>();
            List<System.Drawing.Point> _rectangleDataPoint = new List<System.Drawing.Point>();
            List<string> _rectangleString = new List<string>();
            List<Label> _rectangleLabel = new List<Label>();
            List<Brush> _rectangleColor = new List<Brush>();


            _rectangleDataSize.Clear();
            _rectangleDataPoint.Clear();
            _rectangleLabel.Clear();
            _rectangleString.Clear();
            _rectangleColor.Clear();
            int hole = 0, old_process = 0;

            double scale = (double)_panelHeight / (double)Segmentation_Algorithm.get_MemorySize();


            foreach (Node node in Segmentation_Algorithm.memory)
            {
                _rectangleDataSize.Add(new Size(_rectangleWidth, (int)Math.Ceiling(scale * (node.get_size()))));
                _rectangleDataPoint.Add(new Point(((_panelWidth - _rectangleWidth) / 2) - 10, ((int)Math.Ceiling(node.get_start() * scale)) + 10));

                if (node.get_type()[0] == 'h' || node.get_type()[0] == 'H') //Hole
                {
                    _rectangleString.Add("Hole " + hole);
                    _rectangleColor.Add(Brushes.LightSkyBlue);
                    hole++;
                }
                else if (node.get_type()[0] == 'o' || node.get_type()[0] == 'O') //OldProcess
                {
                    _rectangleString.Add("P" + old_process + " [Old]");
                    _rectangleColor.Add(Brushes.Green);
                    old_process++;
                }
                else if (node.get_type()[0] == 'p' || node.get_type()[0] == 'P') //Process
                {
                    _rectangleString.Add("P" + node.get_id() + ":" + node.get_name());
                    _rectangleColor.Add(Brushes.LightGreen);
                }
                _rectangleLabel.Add(new Label());
                _rectangleLabel[_rectangleLabel.Count - 1].Size = new System.Drawing.Size(30, 10);
                _rectangleLabel[_rectangleLabel.Count - 1].Location = new Point(((_panelWidth - _rectangleWidth) / 2) - 40, ((int)Math.Ceiling(node.get_start() * scale)) + 10);
                _rectangleLabel[_rectangleLabel.Count - 1].Text = node.get_start().ToString();

                if (node.Equals(Segmentation_Algorithm.memory[Segmentation_Algorithm.memory.Count - 1]))
                {
                    _rectangleLabel.Add(new Label());
                    _rectangleLabel[_rectangleLabel.Count - 1].Size = new System.Drawing.Size(30, 10);
                    _rectangleLabel[_rectangleLabel.Count - 1].Location = new Point(((_panelWidth - _rectangleWidth) / 2) - 40, ((int)Math.Ceiling(Segmentation_Algorithm.get_MemorySize() * scale)) + 10);
                    _rectangleLabel[_rectangleLabel.Count - 1].Text = Segmentation_Algorithm.get_MemorySize().ToString();
                }
            }



            System.Drawing.Point location;
            System.Drawing.Size size;
            string y; RectangleF rectF1;
            Label lb;
            Brush bsh;
            StringFormat format = new StringFormat();
            for (int i = 0; i < _rectangleDataSize.Count; i++)
            {
                location = _rectangleDataPoint[i];
                size = _rectangleDataSize[i];
                y = _rectangleString[i];
                bsh = _rectangleColor[i];

                format.LineAlignment = StringAlignment.Center;
                format.Alignment = StringAlignment.Center;
                using (Font font1 = new Font("Courier", 7, FontStyle.Bold, GraphicsUnit.Point))
                {
                    rectF1 = new RectangleF(location, size);
                    e.Graphics.FillRectangle(bsh, rectF1);
                    e.Graphics.DrawString(y, font1, Brushes.White, rectF1, format);
                    e.Graphics.DrawRectangle(Pens.Black, Rectangle.Round(rectF1));

                }
            }
            for (int i = 0; i < _rectangleLabel.Count; i++)
            {

                lb = _rectangleLabel[i];
                lb.Font = new Font("Courier", 6, FontStyle.Regular, GraphicsUnit.Point);
                this.panel1.Controls.Add(lb);
            }
        }


        private void save_holes_Click(object sender, EventArgs e)
        {
            fillHolesEntry.Enabled = false;
            groupBox2.Enabled = false;
            save_holes.Visible = false;
            edit_holes.Visible = true;
            fillProcessEntry.Enabled = true;
            deallocate.Enabled = true;
            Node.AddHoles(Segmentation_Algorithm.Latest_Fine_holeArray, Segmentation_Algorithm.memory);
            if (this.compactionRB.Checked) Node.Check_Your_Holes(Segmentation_Algorithm.memory);
            panel1.Refresh();
        }
        private void deallocate_Click(object sender, EventArgs e)
        {
            new Form4(Forms.form1, this.compactionRB.Checked).Show();
            this.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
        }
    }


}