﻿namespace Segmentation
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.ok_form2 = new System.Windows.Forms.Button();
            this.holes_Data = new System.Windows.Forms.DataGridView();
            this.holes_StartingAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.holes_Size = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Close = new System.Windows.Forms.Button();
            this.deleteHoleEntryButton = new System.Windows.Forms.Button();
            this.newHoleEntryButton = new System.Windows.Forms.Button();
            this.segments_Label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.holes_Data)).BeginInit();
            this.SuspendLayout();
            // 
            // ok_form2
            // 
            this.ok_form2.Location = new System.Drawing.Point(421, 497);
            this.ok_form2.Name = "ok_form2";
            this.ok_form2.Size = new System.Drawing.Size(123, 34);
            this.ok_form2.TabIndex = 0;
            this.ok_form2.Text = "OK";
            this.ok_form2.UseVisualStyleBackColor = true;
            this.ok_form2.Click += new System.EventHandler(this.ok_form2_Click);
            // 
            // holes_Data
            // 
            this.holes_Data.AllowUserToAddRows = false;
            this.holes_Data.AllowUserToDeleteRows = false;
            this.holes_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.holes_Data.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.holes_StartingAddress,
            this.holes_Size});
            this.holes_Data.Location = new System.Drawing.Point(52, 75);
            this.holes_Data.Name = "holes_Data";
            this.holes_Data.RowHeadersWidth = 51;
            this.holes_Data.RowTemplate.Height = 24;
            this.holes_Data.Size = new System.Drawing.Size(492, 234);
            this.holes_Data.TabIndex = 1;
            this.holes_Data.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.holes_Data_RowEnter);
            // 
            // holes_StartingAddress
            // 
            this.holes_StartingAddress.HeaderText = "Starting Address (Base)";
            this.holes_StartingAddress.MinimumWidth = 157;
            this.holes_StartingAddress.Name = "holes_StartingAddress";
            this.holes_StartingAddress.Width = 157;
            // 
            // holes_Size
            // 
            this.holes_Size.HeaderText = "Size (Limit)";
            this.holes_Size.MinimumWidth = 158;
            this.holes_Size.Name = "holes_Size";
            this.holes_Size.Width = 158;
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(49, 497);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(123, 34);
            this.Close.TabIndex = 4;
            this.Close.Text = "Close";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // deleteHoleEntryButton
            // 
            this.deleteHoleEntryButton.Enabled = false;
            this.deleteHoleEntryButton.Location = new System.Drawing.Point(405, 326);
            this.deleteHoleEntryButton.Name = "deleteHoleEntryButton";
            this.deleteHoleEntryButton.Size = new System.Drawing.Size(139, 46);
            this.deleteHoleEntryButton.TabIndex = 3;
            this.deleteHoleEntryButton.Text = "Delete Hole Entry";
            this.deleteHoleEntryButton.UseVisualStyleBackColor = true;
            this.deleteHoleEntryButton.Click += new System.EventHandler(this.deleteHoleEntryButton_Click);
            // 
            // newHoleEntryButton
            // 
            this.newHoleEntryButton.Location = new System.Drawing.Point(52, 326);
            this.newHoleEntryButton.Name = "newHoleEntryButton";
            this.newHoleEntryButton.Size = new System.Drawing.Size(120, 46);
            this.newHoleEntryButton.TabIndex = 2;
            this.newHoleEntryButton.Text = "New Hole Entry";
            this.newHoleEntryButton.UseVisualStyleBackColor = true;
            this.newHoleEntryButton.Click += new System.EventHandler(this.newHoleEntryButton_Click);
            // 
            // segments_Label
            // 
            this.segments_Label.AutoSize = true;
            this.segments_Label.Enabled = false;
            this.segments_Label.Location = new System.Drawing.Point(49, 55);
            this.segments_Label.Name = "segments_Label";
            this.segments_Label.Size = new System.Drawing.Size(82, 17);
            this.segments_Label.TabIndex = 5;
            this.segments_Label.Text = "Holes Data:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 557);
            this.ControlBox = false;
            this.Controls.Add(this.segments_Label);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.deleteHoleEntryButton);
            this.Controls.Add(this.newHoleEntryButton);
            this.Controls.Add(this.holes_Data);
            this.Controls.Add(this.ok_form2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(618, 604);
            this.MinimumSize = new System.Drawing.Size(618, 604);
            this.Name = "Form2";
            this.Text = "Holes";
            ((System.ComponentModel.ISupportInitialize)(this.holes_Data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ok_form2;
        private System.Windows.Forms.DataGridView holes_Data;
        private System.Windows.Forms.DataGridViewTextBoxColumn holes_StartingAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn holes_Size;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button deleteHoleEntryButton;
        private System.Windows.Forms.Button newHoleEntryButton;
        private System.Windows.Forms.Label segments_Label;
    }
}