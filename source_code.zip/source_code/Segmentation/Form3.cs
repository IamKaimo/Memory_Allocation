﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segmentation
{
    public partial class Form3 : Form
    {
        private Form _ftr;
        private int seg_no = 0;
        public Form3(Form1 frm)
        {
            InitializeComponent();
            _ftr = frm;
        }

        private void Lock_Click(object sender, EventArgs e)
        {
            int x;
            if (int.TryParse(textBox1.Text, out x))
            {
                if (x > 0)
                {
                    seg_no = x;
                    this.segments_Label.Enabled = false;
                    this.textBox1.Enabled = false;
                    this.label1.Enabled = false;
                    this.segmentsDataGridView.Enabled = true;
                    this.segments_Label.Enabled = true;
                    this.Lock.Visible = false;
                    this.Unlock.Visible = true;
                    this.add.Enabled = true;
                    this.groupBox1.Enabled = true;
                    for(int i = 0; i < seg_no; i++) segmentsDataGridView.Rows.Add();
                    return;
                }
            }
            MessageBox.Show("Please Enter Positive Integer Number > 0!");
        }

        private void Unlock_Click(object sender, EventArgs e)
        {
            this.segments_Label.Enabled = true;
            this.textBox1.Enabled = true;
            this.label1.Enabled = true;
            this.segmentsDataGridView.Enabled = false;
            this.segments_Label.Enabled = false;
            this.Lock.Visible = true;
            this.Unlock.Visible = false;
            this.add.Enabled = false;
            this.groupBox1.Enabled = false;
            while (segmentsDataGridView.RowCount > 0) segmentsDataGridView.Rows.RemoveAt(0);
        }

        private void cancel_Click(object sender, EventArgs e) 
        { 
            close(); 
        }

        private void close()
        {
            _ftr.Enabled = true;
            this.Close();
        }

        private void add_Click(object sender, EventArgs e)
        {

            for (int i = 0, x; i < segmentsDataGridView.RowCount * segmentsDataGridView.ColumnCount; i++)
            {
                if (segmentsDataGridView.Rows[i / segmentsDataGridView.ColumnCount].Cells[i % segmentsDataGridView.ColumnCount].Value == null) { MessageBox.Show("Please Fill All Segments With Correct Data!\n[There is/are Empty Data Cell/s]"); return; }
                else if (i % segmentsDataGridView.ColumnCount == 0) continue;
                else if (int.TryParse(segmentsDataGridView.Rows[i / segmentsDataGridView.ColumnCount].Cells[i % segmentsDataGridView.ColumnCount].Value.ToString(), out x))
                {
                    if (x < 1) { MessageBox.Show("Please Fill All Segments With Correct Data!\n[Size > 0]"); return; }
                }
                else { MessageBox.Show("Please Fill All Segments With Correct Data!\n[There is/are Non-Integer Number/s]"); return; }
            }

            int[] s_size = new int[segmentsDataGridView.RowCount];
            string[] s_name = new string[segmentsDataGridView.RowCount];
            for (int i = 0; i < segmentsDataGridView.RowCount; i++)
            {
                s_size[i] = Convert.ToInt32(segmentsDataGridView.Rows[i].Cells[1].Value.ToString());
                s_name[i] = segmentsDataGridView.Rows[i].Cells[0].Value.ToString();
            }

            int holes_no = 0;
            for (int i = 0; i < Segmentation_Algorithm.memory.Count; i++)   if(Segmentation_Algorithm.memory[i].get_type() == "hole")holes_no++;
            int[] h_size = new int[holes_no]; holes_no = 0;
            for (int i = 0; i < Segmentation_Algorithm.memory.Count; i++) if (Segmentation_Algorithm.memory[i].get_type() == "hole") { h_size[holes_no] = Segmentation_Algorithm.memory[i].get_end() - Segmentation_Algorithm.memory[i].get_start() + 1; holes_no++; }
            holes_no = h_size.Length;


            if (best_fit.Checked)
            {
                int target, index = 0;
                for (; index < s_size.Length; index++)
                {
                    target = -1;
                    for (int i = 0; i < holes_no; i++)
                    {
                        if (h_size[i] >= s_size[index] && (target == -1 || h_size[i] < h_size[target]))
                        {
                            target = i;
                        }

                    }
                    if (target == -1)
                    {
                        break;
                    }
                    else
                    {
                        h_size[target] = h_size[target] - s_size[index];
                    }
                }

                if (h_size.Length == 0)
                {
                    MessageBox.Show("Process cannot be allocated!");
                }
                else if (index == s_size.Length)
                {
                    //RUN HERE
                    Node Process = new Node("process", s_name, s_size);
                    Node.AllocateProcess(Process, Segmentation_Algorithm.memory, "bf");
                    foreach (Node n in Segmentation_Algorithm.memory)
                    {
                        int z = n.get_start();
                        int zz = n.get_end();
                        string t = n.get_type();
                        if (t == "process")
                        {
                            int id = n.get_id();
                            string name = n.get_name();
                        }
                    }
                    close();
                }
                else
                {
                    MessageBox.Show("Process cannot be allocated!");
                }
            }
            else if (first_fit.Checked)
            {
                int index = 0;
                for (int i = 0; i < holes_no; i++)
                {
                    if(h_size[i] >= s_size[index])
                    {
                        h_size[i] = h_size[i] - s_size[index];
                        index++;
                        i = -1;
                        if (index == s_size.Length) break;
                    }
                }
                if(h_size.Length == 0)
                {
                    MessageBox.Show("Process cannot be allocated!");
                }
                else if(index == s_size.Length)
                {
                    //RUN HERE
                    Node Process = new Node("process", s_name, s_size);
                    Node.AllocateProcess(Process, Segmentation_Algorithm.memory, "ff");
                    foreach (Node n in Segmentation_Algorithm.memory)
                    {
                        int z = n.get_start();
                        int zz = n.get_end();
                        string t = n.get_type();
                        if (t == "process")
                        {
                            int id = n.get_id();
                            string name = n.get_name();
                        }
                    }
                    close();
                }
                else
                {
                    MessageBox.Show("Process cannot be allocated!");
                }

            }
            else
            {
                int target, index = 0;
                for (; index < s_size.Length; index++)
                {
                    target = -1;
                    for (int i = 0; i < holes_no; i++)
                    {
                        if (h_size[i] >= s_size[index] && (target == -1 || h_size[i] > h_size[target]))
                        {
                            target = i;
                        }

                    }
                    if (target == -1)
                    {
                        break;
                    }
                    else
                    {
                        h_size[target] = h_size[target] - s_size[index];
                    }
                }

                if (h_size.Length == 0)
                {
                    MessageBox.Show("Process cannot be allocated!");
                }
                else if (index == s_size.Length)
                {
                    //RUN HERE
                    Node Process = new Node("process", s_name, s_size);
                    Node.AllocateProcess(Process, Segmentation_Algorithm.memory, "wf");
                    foreach (Node n in Segmentation_Algorithm.memory)
                    {
                        int z = n.get_start();
                        int zz = n.get_end();
                        string t = n.get_type();
                        if (t == "process")
                        {
                            int id = n.get_id();
                            string name = n.get_name();
                        }
                    }
                    close();
                }
                else
                {
                    MessageBox.Show("Process cannot be allocated!");
                }
            }
        }
    }
}
